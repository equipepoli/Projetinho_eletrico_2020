package com.example.myapplication

class AdaptadorTest extends groovy.util.GroovyTestCase {
}
