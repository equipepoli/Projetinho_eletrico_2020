package com.example.myapplication;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.ExpandableListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

class Produto {

    private int imagem;
    private String nome;
    private Double valor;

    public Produto(int imagem, String nome, Double valor) {
        this.imagem = imagem;
        this.nome = nome;
        this.valor = valor;
    }

    public int getImagem() {
        return imagem;
    }

    public void setImagem(int imagem) {
        this.imagem = imagem;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

}
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout);

        CheckBox checkBox = (CheckBox) findViewById(R.id.checkBox);
        ExpandableListView elvCompra = (ExpandableListView) findViewById(R.id.elvCompra);

        // cria os grupos
        List<String> lstGrupos = new ArrayList<>();
        lstGrupos.add("Cores");
        lstGrupos.add("Utensilios adicionais");
        lstGrupos.add("Regulagem");
        lstGrupos.add("Guia de Manutenção");

        // cria os itens de cada grupo
        List<Produto> lstcores = new ArrayList<>();
        lstcores.add(new Produto(R.drawable.minimalista,"Minimalista escuro", (double) 100));
        lstcores.add(new Produto(R.drawable.destaque,"Destaque", (double) 200));
        lstcores.add(new Produto(R.drawable.social,"Social", (double)150));


        List<Produto> lstAd = new ArrayList<>();
        lstAd.add(new Produto(R.drawable.capaantiperm,"Capa - anti permeavel", (double)300));
        lstAd.add(new Produto(R.drawable.cargateto,"Suporte para carga no teto", (double)350));
        lstAd.add(new Produto(R.drawable.chapeusolar,"Chapéu - solar", (double)350));
        lstAd.add(new Produto(R.drawable.farol,"Farol", (double)350));
        lstAd.add(new Produto(R.drawable.retrovisor,"Retrovisor", (double)350));
        lstAd.add(new Produto(R.drawable.buzina,"Buzina", (double)350));
        lstAd.add(new Produto(R.drawable.celular,"Suporte para celular", (double)350));
        lstAd.add(new Produto(R.drawable.gopro,"Suporte para GoPro", (double)350));
        lstAd.add(new Produto(R.drawable.estepe,"Suporte Estepe", (double)350));
        lstAd.add(new Produto(R.drawable.led,"Lâmpada de led no teto parte frontal", (double)350));
        lstAd.add(new Produto(R.drawable.autofalante,"Kit Audio - Bateria", (double)350));

        List<Produto> lstRegulagem = new ArrayList<>();
        lstRegulagem.add(new Produto(R.drawable.apoioperna,"Apoio das pernas", (double)0));

        List<Produto> lstManu = new ArrayList<>();
        lstManu.add(new Produto(R.drawable.ferramentas,"Ferramentas", (double)0));
        lstManu.add(new Produto(R.drawable.pecas,"Peças", (double)0));

        // cria o "relacionamento" dos grupos com seus itens
        HashMap<String, List<Produto>> lstItensGrupo = new HashMap<>();
        lstItensGrupo.put(lstGrupos.get(0),lstcores );
        lstItensGrupo.put(lstGrupos.get(1), lstAd);
        lstItensGrupo.put(lstGrupos.get(2), lstRegulagem);
        lstItensGrupo.put(lstGrupos.get(3), lstManu);

        // cria um adaptador (BaseExpandableListAdapter) com os dados acima
        Adaptador adaptador = new Adaptador(this, lstGrupos, lstItensGrupo);
        // define o apadtador do ExpandableListView
        elvCompra.setAdapter(adaptador);
    }

}