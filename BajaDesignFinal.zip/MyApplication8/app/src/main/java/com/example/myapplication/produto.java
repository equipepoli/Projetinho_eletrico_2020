class Produto {

    private String nome;
    private int imagem;
    private Double valor;

    public Produto(int imagem, String nome, Double valor) {
        this.imagem =  imagem;
        this.nome = nome;
        this.valor = valor;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getImagem() { return imagem; } //colocando a imagem

    public void setImagem(int imagem) { this.imagem = imagem; } //colocando a imagem

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

}
